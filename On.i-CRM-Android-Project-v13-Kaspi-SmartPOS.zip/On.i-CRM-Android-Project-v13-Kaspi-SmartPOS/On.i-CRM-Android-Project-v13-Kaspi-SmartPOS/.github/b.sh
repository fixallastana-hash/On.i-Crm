#!/usr/bin/env bash
set -e

echo "=== STEP 1: check repo override ==="
if [ -f android-project/app/src/main/assets/index.html ]; then
  cp android-project/app/src/main/assets/index.html /tmp/oni_index_override.html
  echo "Saved repo index.html ($(wc -c < /tmp/oni_index_override.html) bytes)"
else
  echo "No repo override found (that is ok)"
fi

echo "=== STEP 2: find and unzip ==="
Z=$(find . -maxdepth 2 -type f -name '*.zip' -not -path './.git/*' | head -1)
[ -z "$Z" ] && { echo "no-zip"; exit 1; }
echo "Found ZIP: $Z"
rm -rf work android-project
mkdir work
unzip -q "$Z" -d work
for i in 1 2 3; do
  I=$(find work -maxdepth 4 -type f -name '*.zip' | head -1)
  [ -z "$I" ] && break
  unzip -q -o "$I" -d work
  rm -f "$I"
done

echo "=== STEP 3: locate index.html inside ZIP ==="
IDXFILE=$(find work -type f \( -name 'index.html' -o -name 'index.html.html' \) -path '*assets*' | head -1)
[ -z "$IDXFILE" ] && IDXFILE=$(find work -type f \( -name 'index.html' -o -name 'index.html.html' \) | head -1)
[ -z "$IDXFILE" ] && IDXFILE=$(find work -type f -name 'index.html*' ! -name '*.zip' | head -1)
echo "IDXFILE=$IDXFILE"
if [ -z "$IDXFILE" ]; then
  echo "ERROR: index.html not found anywhere in ZIP"
  echo "--- STRUCTURE ---"
  find work -type f | head -80
  exit 1
fi
echo "Found index.html inside ZIP: $IDXFILE ($(wc -c < "$IDXFILE") bytes)"

echo "=== STEP 4: locate MainActivity ==="
S=work
[ ! -f "$S/MainActivity.java" ] && S=$(dirname "$(find work -maxdepth 5 -name MainActivity.java | head -1)")
echo "MainActivity dir: $S"

echo "=== STEP 5: create project skeleton ==="
mkdir -p android-project/app/src/main/java/com/oni/crm
mkdir -p android-project/app/src/main/res/values
mkdir -p android-project/app/src/main/res/xml
mkdir -p android-project/app/src/main/res/mipmap-hdpi
mkdir -p android-project/app/src/main/assets/tessdata
mkdir -p android-project/app/libs

cat > android-project/settings.gradle <<'EOF'
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
  repositories { google(); mavenCentral() }
}
rootProject.name = "OniCRM"
include ':app'
EOF

cat > android-project/build.gradle <<'EOF'
plugins { id 'com.android.application' version '8.5.2' apply false }
EOF

cat > android-project/gradle.properties <<'EOF'
android.useAndroidX=true
android.enableJetifier=true
org.gradle.jvmargs=-Xmx3072m -Dfile.encoding=UTF-8
android.nonTransitiveRClass=false
EOF

cat > android-project/app/build.gradle <<'EOF'
plugins { id 'com.android.application' }
configurations.all {
  exclude group: 'org.jetbrains.kotlin', module: 'kotlin-stdlib-jdk7'
  exclude group: 'org.jetbrains.kotlin', module: 'kotlin-stdlib-jdk8'
}
android {
  namespace 'com.oni.crm'
  compileSdk 34
  defaultConfig {
    applicationId "com.oni.crm"
    minSdk 24
    targetSdk 34
    versionCode 1
    versionName "1.0"
  }
  compileOptions {
    sourceCompatibility JavaVersion.VERSION_17
    targetCompatibility JavaVersion.VERSION_17
  }
  packagingOptions { jniLibs { useLegacyPackaging = true } }
  lint { abortOnError false; checkReleaseBuilds false }
}
dependencies {
  implementation 'androidx.core:core:1.13.1'
  implementation 'com.rmtheis:tess-two:9.1.0'
  implementation fileTree(dir: 'libs', include: ['*.jar'])
}
EOF

echo "=== STEP 6: copy sources from ZIP ==="
cp "$S/MainActivity.java" android-project/app/src/main/java/com/oni/crm/ 2>/dev/null || true
cp "$S/CrmFileProvider.java" android-project/app/src/main/java/com/oni/crm/ 2>/dev/null || true
cp "$S/AndroidManifest.xml" android-project/app/src/main/ 2>/dev/null || true
cp "$S/colors.xml" android-project/app/src/main/res/values/ 2>/dev/null || true
cp "$S/strings.xml" android-project/app/src/main/res/values/ 2>/dev/null || true
cp "$S/styles.xml" android-project/app/src/main/res/values/ 2>/dev/null || true
cp "$S/file_paths.xml" android-project/app/src/main/res/xml/ 2>/dev/null || true
cp "$S/ic_launcher.png" android-project/app/src/main/res/mipmap-hdpi/ 2>/dev/null || true
cp "$S/proguard-rules.pro" android-project/app/ 2>/dev/null || true

echo "=== STEP 7: copy index.html (always rename to index.html) ==="
cp "$IDXFILE" android-project/app/src/main/assets/index.html
echo "Copied: $(wc -c < android-project/app/src/main/assets/index.html) bytes"

echo "=== STEP 8: restore repo override if exists ==="
if [ -f /tmp/oni_index_override.html ]; then
  cp /tmp/oni_index_override.html android-project/app/src/main/assets/index.html
  echo "Restored repo override ($(wc -c < android-project/app/src/main/assets/index.html) bytes)"
fi

echo "=== STEP 9: final check ==="
ls -lh android-project/app/src/main/assets/index.html
echo "=============================================="

echo "=== STEP 10: download traineddata ==="
cd android-project/app/src/main/assets/tessdata
curl -sL -O "https://raw.githubusercontent.com/tesseract-ocr/tessdata/main/eng.traineddata"
curl -sL -O "https://raw.githubusercontent.com/tesseract-ocr/tessdata/main/rus.traineddata"
ls -lh
cd - > /dev/null

[ ! -f android-project/app/src/main/AndroidManifest.xml ] && { echo "no-manifest"; exit 1; }
sed -i -E 's/[[:space:]]+package="[^"]*"//g' android-project/app/src/main/AndroidManifest.xml

python3 .github/p.py
python3 .github/patch_index.py

echo "PROJECT_DIR=$PWD/android-project" >> "$GITHUB_ENV"
