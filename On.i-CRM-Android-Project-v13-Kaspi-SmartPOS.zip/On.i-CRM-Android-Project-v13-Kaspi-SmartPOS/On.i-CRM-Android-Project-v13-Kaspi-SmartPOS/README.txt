Place xlsx.full.min.js from SheetJS 0.18.5 here for fully offline Excel import/export.
